My project is a website for book info. You search for a book (with or without a account made) by its ISBN number and it will use googles api to find the book. 
The website will then display some details about the book, such as the author(s) or number of pages. If you create an account, you can save the book in your account, 
where you can then view it in your account tab and rate it. You can also decide whether you have read the book, or if you want to read the book. You can also give
it a rating out of 5.